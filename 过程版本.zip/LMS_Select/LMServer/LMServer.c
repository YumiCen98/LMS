#include "Connect.h"
#include <unistd.h>
#include <sys/select.h>
#include <sys/time.h>

int main(int argc, char const *argv[])
{
    if(argc < 3)
    {
        printf("Usage：%s <ip> <port>\n", argv[0]);
        return -1;
    }

    int sockfd, clientfd;
    struct sockaddr_in clientaddr;
    MSG msg;
    int bytes;

    if((sockfd = CreateServer(argv[1], argv[2])) < 0)
    {
        printf("create server error\n");
        return -1;
    }

    //使用select实现TCP并发
    int i;
    //1.创建文件描述符集合并清空
    fd_set readfds, tempfds;
    FD_ZERO(&readfds);
    FD_ZERO(&tempfds);

    //2.将需要操作的文件描述符添加到集合
    FD_SET(sockfd, &tempfds);
    int maxfd = sockfd;
next:
    while(1)
    {
        readfds = tempfds;

        //3.调用select函数阻塞等待文件描述符准备就绪
        if(select(maxfd+1, &readfds, NULL, NULL, NULL) == -1)
        {
            ERR_LOG("fail to select");
        }

        for(i=sockfd; i<=maxfd; i++)
        {
            if(FD_ISSET(i, &readfds) == 1)
            {
                if(i == sockfd)
                {
                    //等待客户端连接，并保存客户端的地址
                    if((clientfd = WaitConnect(sockfd, &clientaddr)) < 0)
                    {
                        printf("connect server error\n");
                        return -1;
                    }

                    FD_SET(clientfd, &tempfds);
                    maxfd = maxfd > clientfd ? maxfd : clientfd;
                }
                else
                {
                    //判断客户端是否退出
                    if((bytes = RecvMsg(clientfd, &msg)) == 0)
                    {
                        printf("[%s:%d]退出了\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
                        goto next;
                    }
                    //printf("bytes = %d\n", bytes);
                    printf("OptCode：%d\n", msg.OptCode);
                    printf("Text：%s\n", msg.text);

                    memset(&msg, 0, sizeof(MSG));
                }
            }
        }
    }
    
    return 0;
}