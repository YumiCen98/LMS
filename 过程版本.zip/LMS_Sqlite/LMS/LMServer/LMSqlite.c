#include "LMSqlite.h"

//创建/打开数据库
//open后需要将数据库句柄返回，否则后面的操作无法进行
sqlite3 *do_sqlopen(const char *dbname, sqlite3 *db)
{
    if(sqlite3_open(DBNAME, &db) != SQLITE_OK)
    {
        printf(FONT_COLOR_RED"[数据库创建/打开错误]%s\n"COLOR_NONE, sqlite3_errmsg(db));
    }
    else
    {
        printf(FONT_COLOR_YELLOW"[数据库创建/打开成功]\n"COLOR_NONE);
        return db;
    }

}

//创建表
void do_createtable(sqlite3 *db, const char *sqlcmd)
{
    char *errmsg;
    if(sqlite3_exec(db, sqlcmd, NULL, NULL, &errmsg) != SQLITE_OK)
    {
        printf(FONT_COLOR_RED"[创建表失败]%s\n"COLOR_NONE, errmsg);
    }
    else
    {
        printf(FONT_COLOR_YELLOW"[创建表成功]\n"COLOR_NONE);
    }
}

int do_check_user(sqlite3 *db, MSG msg, const char *sqlcmd)
{
    char *errmsg, **result;
    int nrow, ncolum;

    if(sqlite3_get_table(db, sqlcmd, &result, &nrow, &ncolum, &errmsg) != SQLITE_OK)
    {
        //printf(FONT_COLOR_RED"[查询表失败]%s\n"COLOR_NONE, errmsg);
        return -1;
    }
    if(nrow == 0)
    {
        //printf(FONT_COLOR_RED"[账号或密码有误]\n"COLOR_NONE);
        return 1;
    }
    else
    {
        //printf(FONT_COLOR_YELLOW"[查询表成功]\n"COLOR_NONE);
        return 0;
    }
}

int do_sqlinsert(sqlite3 *db, MSG msg, const char *sqlcmd)
{
    char *errmsg;

    if(sqlite3_exec(db, sqlcmd, NULL, NULL, &errmsg) != SQLITE_OK)
    {
        printf(FONT_COLOR_RED"[插入数据失败]%s\n"COLOR_NONE, errmsg);
        if(errno == 2)
        {
            return 1;
        }
        return -1;
    }
    else
    {
        printf(FONT_COLOR_RED"[插入数据成功]\n"COLOR_NONE);
        return 0;
    }
}

