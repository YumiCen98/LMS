#include "Connect.h"
#include "User.h"

int main(int argc, char const *argv[])
{
    if(argc < 3)
    {
        printf(FONT_COLOR_RED"[Usage：%s <ip> <port>]\n"COLOR_NONE, argv[0]);
        return -1;
    }

    int sockfd, clientfd;
    struct sockaddr_in clientaddr;
    MSG msg;
    int bytes;

    int Opt, ret;

    sockfd = ConnectServer(argv[1], argv[2]);

    while(1)
    {
        memset(&msg, 0, sizeof(MSG));
Next:
        //主界面
        printf(" \
            ********************\n \
            ******1、注册******\n \
            ******2、登录******\n \
            ******3、管理******\n \
            ********************\n");

        printf(FONT_COLOR_BLUE"input:>"COLOR_NONE);
        scanf("%d", &Opt);
        switch(Opt)
        {
            case 1:
                if((ret = regist(sockfd, msg)) == 0)
                {
                    printf(FONT_COLOR_YELLOW"[注册成功]\n"COLOR_NONE);
                }
                else if(ret == 1)
                {
                    printf(FONT_COLOR_RED"[用户已注册，请登录]\n"COLOR_NONE);
                }
                else if(ret == -1)
                {
                    printf(FONT_COLOR_RED"[注册失败]\n"COLOR_NONE);
                }
                break;
            case 2:
                if(login(sockfd, msg) == 0)
                {
                    printf(FONT_COLOR_YELLOW"[登录成功]\n"COLOR_NONE);
                }
                else
                {
                    printf(FONT_COLOR_RED"[登录失败]\n"COLOR_NONE);
                }
                break;
            case 3:
                if(login(sockfd, msg) == 0)
                {
                    printf(FONT_COLOR_YELLOW"[管理员登录成功]\n"COLOR_NONE);
                }
                else
                {
                    printf(FONT_COLOR_RED"[管理员登录失败]\n"COLOR_NONE);
                }
                break;

            default:
                printf(FONT_COLOR_RED"请输入正确的序号\n"COLOR_NONE);
                goto Next;
        }
/*
        printf(FONT_COLOR_BLUE"input:>"COLOR_NONE);
        fgets(msg.text, N, stdin);
        msg.text[strlen(msg.text)-1] = '\0';

        memset(&msg, 0, sizeof(MSG));

        RecvMsg(sockfd, &msg);
        printf(FONT_COLOR_YELLOW"\n[Server Message]%s\n"COLOR_NONE, msg.text);
        */
    }

    return 0;
}