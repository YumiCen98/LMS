#include "LMSqlite.h"

//创建/打开数据库
//open后需要将数据库句柄返回，否则后面的操作无法进行
sqlite3 *do_sqlopen(const char *dbname, sqlite3 *db)
{
    if(sqlite3_open(dbname, &db) != SQLITE_OK)
    {
        printf(FONT_COLOR_RED"[数据库创建/打开错误]%s\n"COLOR_NONE, sqlite3_errmsg(db));
    }
    else
    {
        printf(FONT_COLOR_YELLOW"[数据库创建/打开成功]\n"COLOR_NONE);
        return db;
    }

}

//创建表
void do_createtable(sqlite3 *db, const char *sqlcmd)
{
    char *errmsg;
    if(sqlite3_exec(db, sqlcmd, NULL, NULL, &errmsg) != SQLITE_OK)
    {
        printf(FONT_COLOR_RED"[创建表失败]%s\n"COLOR_NONE, errmsg);
    }
    else
    {
        printf(FONT_COLOR_YELLOW"[创建表成功]\n"COLOR_NONE);
    }
}

int do_check_user(sqlite3 *db, MSG msg, const char *sqlcmd)
{
    char *errmsg, **result;
    int nrow, ncolum;

    if(sqlite3_get_table(db, sqlcmd, &result, &nrow, &ncolum, &errmsg) != SQLITE_OK)
    {
        //printf(FONT_COLOR_RED"[查询表失败]%s\n"COLOR_NONE, errmsg);
        return -1;
    }
    if(nrow == 0)
    {
        //printf(FONT_COLOR_RED"[账号或密码有误]\n"COLOR_NONE);
        return 1;
    }
    else
    {
        //printf(FONT_COLOR_YELLOW"[查询表成功]\n"COLOR_NONE);
        return 0;
    }
}

int do_sqlinsert(sqlite3 *db, MSG msg, const char *sqlcmd)
{
    char *errmsg;

    if(sqlite3_exec(db, sqlcmd, NULL, NULL, &errmsg) != SQLITE_OK)
    {
        printf(FONT_COLOR_RED"[插入数据失败]%s\n"COLOR_NONE, errmsg);
        if(errno == 2)
        {
            return 1;
        }
        return -1;
    }
    else
    {
        printf(FONT_COLOR_YELLOW"[插入数据成功]\n"COLOR_NONE);
        return 0;
    }
}

int search_callback(void *arg, int f_num, char **f_value, char **f_name)
{
    int sockfd = *(int *)arg;
    MSG msg;

    sprintf(msg.text, "<<%s>> - 作者:%s - 类别:%s - 剩余馆藏:%s", f_value[0], f_value[1], f_value[2], f_value[3]);
    //printf(FONT_COLOR_YELLOW"[获取数据库成功]\n"COLOR_NONE);
    printf("%s\n", msg.text);

    SendMsg(sockfd, &msg);
    return 0;
}

void do_search(int sockfd, sqlite3 *db, MSG msg, const char *sqlcmd)
{
    char *errmsg, **result;
    int nrow, ncolum;

    if(sqlite3_get_table(db, sqlcmd, &result, &nrow, &ncolum, &errmsg) != SQLITE_OK)
    {
        printf(FONT_COLOR_RED"[查询表失败]%s\n"COLOR_NONE, errmsg);
        sprintf(msg.text, "book_search_fail");
        SendMsg(sockfd, &msg);
        return ;
    }
    if(nrow == 0)
    {
        printf(FONT_COLOR_YELLOW"[没有该书]\n"COLOR_NONE);
        sprintf(msg.text, "no_book");
        SendMsg(sockfd, &msg);
        return ;
    }
    else
    {
        printf(FONT_COLOR_YELLOW"[查询表成功]\n"COLOR_NONE);
        if(sqlite3_exec(db, sqlcmd, search_callback, (void *)&sockfd, &errmsg) != SQLITE_OK)
        {
            printf(FONT_COLOR_RED"[获取结果失败]%s\n"COLOR_NONE, errmsg);
            sqlite3_free(errmsg);
            sprintf(msg.text, "book_search_fail");
            SendMsg(sockfd, &msg);
            return ;
        }
        else
        {
            printf(FONT_COLOR_YELLOW"[获取结果成功]\n"COLOR_NONE);
            return ;
        }
    }
}



