#include "Operation.h"

//查询图书
void book_search(int sockfd, MSG msg)
{
    int Opt, flag=1;
NEXT:
    printf(FONT_COLOR_YELLOW"[图书查询界面]\n"COLOR_NONE);
    printf(" \
            ********************\n \
            ****1、按书名查找****\n \
            ****2、按作者查找****\n \
            **3、按类别(待完善)**\n \
            ********************\n");
    
    printf(FONT_COLOR_BLUE"input:>"COLOR_NONE);
    scanf("%d", &Opt);
    switch(Opt)
    {
        case 1:
            msg.OptCode = 4;
            printf(FONT_COLOR_BLUE"书名(不需要书名号):>"COLOR_NONE);
            scanf("%s", msg.text);
            break;
        case 2:
            msg.OptCode = 5;
            printf(FONT_COLOR_BLUE"作者:>"COLOR_NONE);
            scanf("%s", msg.text);
            break;
        case 3:
        /*
            msg.OptCode = 6;
            printf("1、文学 2、技术 3、科学\n");
            printf(FONT_COLOR_BLUE"选择类别:>"COLOR_NONE);
            scanf("%s", msg.text);
            */
            printf(FONT_COLOR_RED"待完善\n"COLOR_NONE);
            goto NEXT;
            break;
        default:
            printf(FONT_COLOR_RED"请输入正确的序号\n"COLOR_NONE);
            goto NEXT;
    }

    SendMsg(sockfd, &msg);
    memset(&msg, 0, sizeof(MSG));
    RecvMsg(sockfd, &msg);

    if(strcmp(msg.text, "book_search_fail") == 0)
    {
        printf(FONT_COLOR_RED"[藏书查询失败]\n"COLOR_NONE);
    }
    else if(strcmp(msg.text, "no_book") == 0)
    {
        printf(FONT_COLOR_RED"[结果为空]\n"COLOR_NONE);
    }
    else
    {
        printf(FONT_COLOR_YELLOW"[藏书查询成功]\n"COLOR_NONE);
        printf("%s\n", msg.text);
    }
}

//借阅图书
int book_borrow(int sockfd, MSG msg)
{
    int Opt;
    msg.OptCode = 5;

    printf(FONT_COLOR_YELLOW"[借阅界面]\n"COLOR_NONE);
    printf(FONT_COLOR_BLUE"借阅书名(不需要书名号):>"COLOR_NONE);
    scanf("%s", msg.text);
    SendMsg(sockfd, &msg);
    memset(&msg, 0, sizeof(MSG));

    RecvMsg(sockfd, &msg);
    if(strcmp(msg.text, "regist_success") == 0)
    {
        //printf(FONT_COLOR_YELLOW"[注册成功]\n"COLOR_NONE);
        return 0;
    }
    else if(strcmp(msg.text, "user_exist") == 0)
    {
        //printf(FONT_COLOR_RED"[用户已注册，请登录]\n"COLOR_NONE);
        return 1;
    }
    //else if(strcmp(msg.text, "regist_fail") == 0)
    else
    {
        //printf(FONT_COLOR_RED"[注册失败]\n"COLOR_NONE);
        return -1;
    }
}

int book_return(int sockfd, MSG msg)
{
    int Opt;
    msg.OptCode = 6;
    printf(FONT_COLOR_YELLOW"[还书界面]\n"COLOR_NONE);
    printf(FONT_COLOR_BLUE"待还书名(不需要书名号):>"COLOR_NONE);
    scanf("%s", msg.text);

    SendMsg(sockfd, &msg);
    memset(&msg, 0, sizeof(MSG));
    RecvMsg(sockfd, &msg);
    if(strcmp(msg.text, "regist_success") == 0)
    {
        //printf(FONT_COLOR_YELLOW"[注册成功]\n"COLOR_NONE);
        return 0;
    }
    else if(strcmp(msg.text, "user_exist") == 0)
    {
        //printf(FONT_COLOR_RED"[用户已注册，请登录]\n"COLOR_NONE);
        return 1;
    }
    //else if(strcmp(msg.text, "regist_fail") == 0)
    else
    {
        //printf(FONT_COLOR_RED"[注册失败]\n"COLOR_NONE);
        return -1;
    }
}

