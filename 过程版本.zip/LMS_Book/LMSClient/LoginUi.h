#ifndef __LOGINUI_H_
#define __LOGINUI_H_

#include "Connect.h"

void User_Centen(int sockfd, MSG msg);

#endif