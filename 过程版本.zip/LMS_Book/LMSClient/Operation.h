#ifndef __OPERATION_H_
#define __OPERATION_H_

#include "Connect.h"

void book_search(int sockfd, MSG msg);

int book_borrow(int sockfd, MSG msg);

int book_return(int sockfd, MSG msg);

#endif