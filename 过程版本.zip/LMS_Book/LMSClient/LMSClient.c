#include "Connect.h"
#include "User.h"
#include "Operation.h"
#include "LoginUi.h"

int main(int argc, char const *argv[])
{
    if(argc < 3)
    {
        printf(FONT_COLOR_RED"[Usage：%s <ip> <port>]\n"COLOR_NONE, argv[0]);
        return -1;
    }

    int sockfd, clientfd;
    struct sockaddr_in clientaddr;
    MSG msg;
    int bytes;

    int Opt, ret;

    sockfd = ConnectServer(argv[1], argv[2]);

    while(1)
    {
        memset(&msg, 0, sizeof(MSG));
Next:
        //主界面
        printf(" \
            ********************\n \
            ******1、注册******\n \
            ******2、登录******\n \
            ******3、管理******\n \
            ******0、退出******\n \
            ********************\n");

        printf(FONT_COLOR_BLUE"input:>"COLOR_NONE);
        scanf("%d", &Opt);
        switch(Opt)
        {
            case 0:
                exit(0);
            case 1:
                regist(sockfd, msg);
                break;
            case 2:
                if(login(sockfd, msg) == 0)
                {
                    User_Centen(sockfd, msg);
                }
                else
                {
                    goto Next;
                }
                break;
            case 3:
                manage(sockfd, msg);
                break;

            default:
                printf(FONT_COLOR_RED"请输入正确的序号\n"COLOR_NONE);
                goto Next;
        }
/*
        printf(FONT_COLOR_BLUE"input:>"COLOR_NONE);
        fgets(msg.text, N, stdin);
        msg.text[strlen(msg.text)-1] = '\0';

        memset(&msg, 0, sizeof(MSG));

        RecvMsg(sockfd, &msg);
        printf(FONT_COLOR_YELLOW"\n[Server Message]%s\n"COLOR_NONE, msg.text);
        */
    }

    return 0;
}