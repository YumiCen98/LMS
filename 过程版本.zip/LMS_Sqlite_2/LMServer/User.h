#ifndef __USER_H_
#define __USER_H_

#include <string.h>
#include "LMSqlite.h"
#include "Connect.h"

void do_regist(int sockfd, MSG msg, sqlite3 *db);

void do_login(int sockfd, MSG msg, sqlite3 *db);

void do_manage(int sockfd, MSG msg);

int book_search(int sockfd, MSG msg);

int book_borrow(int sockfd, MSG msg);

int book_return(int sockfd, MSG msg);

#endif