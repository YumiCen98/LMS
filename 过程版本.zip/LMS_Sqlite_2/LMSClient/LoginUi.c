#include "LoginUi.h"

void User_Centen(void)
{
    int Opt;
    //登录后界面
    printf(" \
        ********************\n \
        ******1、查询******\n \
        ******2、借阅******\n \
        ******3、还书******\n \
        ********************\n");

    printf(FONT_COLOR_BLUE"input:>"COLOR_NONE);
    scanf("%d", &Opt);
    switch(Opt)
    {
        case 1:
            if((ret = regist(sockfd, msg)) == 0)
            {
                printf(FONT_COLOR_YELLOW"[注册成功]\n"COLOR_NONE);
            }
            else if(ret == 1)
            {
                printf(FONT_COLOR_RED"[用户已注册，请登录]\n"COLOR_NONE);
            }
            else if(ret == -1)
            {
                printf(FONT_COLOR_RED"[注册失败]\n"COLOR_NONE);
            }
            break;
        case 2:
            if((ret = login(sockfd, msg)) == 0)
            {
                printf(FONT_COLOR_YELLOW"[登录成功]\n"COLOR_NONE);
                
            }
            else if(ret == 1)
            {
                printf(FONT_COLOR_RED"[账号或密码有误]\n"COLOR_NONE);
            }
            else if(ret == -1)
            {
                printf(FONT_COLOR_RED"[登录失败]\n"COLOR_NONE);
            }
            break;
        case 3:
            if(login(sockfd, msg) == 0)
            {
                printf(FONT_COLOR_YELLOW"[管理员登录成功]\n"COLOR_NONE);
            }
            else
            {
                printf(FONT_COLOR_RED"[管理员登录失败]\n"COLOR_NONE);
            }
            break;

        default:
            printf(FONT_COLOR_RED"请输入正确的序号\n"COLOR_NONE);
            goto Next;
    }
}