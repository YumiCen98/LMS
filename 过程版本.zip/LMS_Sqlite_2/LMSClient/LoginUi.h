#ifndef __LOGINUI_H_
#define __LOGINUI_H_

void User_Centen(void);

#endif