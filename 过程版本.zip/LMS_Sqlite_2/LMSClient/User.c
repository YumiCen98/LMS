#include "User.h"

int regist(int sockfd, MSG msg)
{
    msg.OptCode = 1;
    printf(FONT_COLOR_YELLOW"[注册界面]\n"COLOR_NONE);
    printf(FONT_COLOR_BLUE"账号:>"COLOR_NONE);
    scanf("%s", msg.Account);

    printf(FONT_COLOR_BLUE"密码:>"COLOR_NONE);
    scanf("%s", msg.text);

    SendMsg(sockfd, &msg);
    memset(&msg, 0, sizeof(MSG));
    RecvMsg(sockfd, &msg);
    if(strcmp(msg.text, "regist_success") == 0)
    {
        //printf(FONT_COLOR_YELLOW"[注册成功]\n"COLOR_NONE);
        return 0;
    }
    else if(strcmp(msg.text, "user_exist") == 0)
    {
        //printf(FONT_COLOR_RED"[用户已注册，请登录]\n"COLOR_NONE);
        return 1;
    }
    //else if(strcmp(msg.text, "regist_fail") == 0)
    else
    {
        //printf(FONT_COLOR_RED"[注册失败]\n"COLOR_NONE);
        return -1;
    }
}

int login(int sockfd, MSG msg)
{
    msg.OptCode = 2;
    printf(FONT_COLOR_YELLOW"[登录界面]\n"COLOR_NONE);
    printf(FONT_COLOR_BLUE"账号:>"COLOR_NONE);
    scanf("%s", msg.Account);

    printf(FONT_COLOR_BLUE"密码:>"COLOR_NONE);
    scanf("%s", msg.text);

    SendMsg(sockfd, &msg);
    memset(&msg, 0, sizeof(MSG));
    RecvMsg(sockfd, &msg);
    if(strcmp(msg.text, "login_success") == 0)
    {
        //printf(FONT_COLOR_YELLOW"[登录成功]\n"COLOR_NONE);
        return 0;
    }
    else if(strcmp(msg.text, "Ac_or_Pd_error") == 0)
    {
        //printf(FONT_COLOR_RED"[账号或密码有误]\n"COLOR_NONE);
        return 1;
    }
    else
    {
        //printf(FONT_COLOR_RED"[登录失败]\n"COLOR_NONE);
        return -1;
    }
}

int manage(int sockfd, MSG msg)
{
    msg.OptCode = 3;
    printf(FONT_COLOR_YELLOW"[管理员登录界面]\n"COLOR_NONE);
    printf(FONT_COLOR_BLUE"账号:>"COLOR_NONE);
    scanf("%s", msg.Account);

    printf(FONT_COLOR_BLUE"密码:>"COLOR_NONE);
    scanf("%s", msg.text);

    SendMsg(sockfd, &msg);
    memset(&msg, 0, sizeof(MSG));
    RecvMsg(sockfd, &msg);
    if(strcmp(msg.text, "manage_success") == 0)
    {
        //printf(FONT_COLOR_YELLOW"[登录成功]\n"COLOR_NONE);
        return 0;
    }
    else
    {
        //printf(FONT_COLOR_RED"[登录失败]\n"COLOR_NONE);
        return -1;
    }
}
