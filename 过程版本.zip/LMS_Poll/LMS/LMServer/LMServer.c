#include "Connect.h"
#include <unistd.h>
#include <poll.h>
#define OPEN_MAX 100

int main(int argc, char const *argv[])
{
    if(argc < 3)
    {
        printf("Usage：%s <ip> <port>\n", argv[0]);
        return -1;
    }

    int sockfd, clientfd;
    struct sockaddr_in clientaddr;
    MSG msg;
    int bytes;

    if((sockfd = CreateServer(argv[1], argv[2])) < 0)
    {
        printf("create server error\n");
        return -1;
    }

    //使用poll实现IO多路复用
    struct pollfd client[OPEN_MAX];
    int i = 0, maxi = 0;

    for(; i<OPEN_MAX; i++)
        client[i].fd = -1; //初始化poll结构中的文件描述符fd

    client[0].fd = sockfd; //需要监测的描述符
    client[0].events = POLLIN; //普通或优先级带数据可读

    //对已连接客户端数据处理
    while(1)
    {
        int ret;
        //调用poll函数阻塞等待文件描述符准备就绪
        if((ret = poll(client, maxi+1, -1)) < 0)
        {
            ERR_LOG("fail to poll");
        }

        //监测sockfd(监听套接字)是否存在连接
        if((client[0].revents & POLLIN) == POLLIN)
        {
            //等待客户端连接，并保存客户端的地址
            if((clientfd = WaitConnect(sockfd, &clientaddr)) < 0)
            {
                printf("connect server error\n");
                return -1;
            }

            //将提取到的clientfd放入poll结构体数组中，以便于poll函数监测
            for(i=1; i<OPEN_MAX; i++)
            {
                if(client[i].fd < 0)
                {
                    client[i].fd = clientfd;
                    client[i].events = POLLIN;
                    break;
                }
            }

            if(i > maxi)
                maxi = i;

            if(--ret <= 0)
                continue;
        }
 
        //继续响应就绪的描述符
        for(i=1; i<=maxi; i++)
        {
            if(client[i].fd < 0)
                continue;

            if(client[i].revents & (POLLIN | POLLERR))
            {
                printf("fd = %d\n", client[i].fd);
                //判断客户端是否退出
                if((bytes = RecvMsg(client[i].fd, &msg)) == 0)
                {
                    printf("[%s:%d]退出了\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
                    close(client[i].fd);
                    client[i].fd = 1;
                }
                //接受客户端数据
                else
                {
                    printf("bytes = %d\n", bytes);
                    //printf("OptCode：%d\n", msg.OptCode);
                    printf("# %s\n", msg.text);
                    memset(msg.text, 0, N);

                    switch(msg.OptCode)
                    {
                        case 0:
                            strcat(msg.text, "接收成功");
                            
                            break;
                        case 1:
                            
                            break;
                        case 3:

                            break;
                        default:
                            strcat(msg.text, "操作码错误");


                    }
                    SendMsg(clientfd, &msg);
                    memset(&msg, 0, sizeof(MSG));
                    
                }

                //所有的就绪描述符处理完了，就退出当前的for循环，继续poll监测
                if(--ret <= 0)
                    break;
            }
        }
    }

    return 0;
}