#include "Connect.h"

int main(int argc, char const *argv[])
{
    if(argc < 3)
    {
        printf("Usage：%s <ip> <port>\n", argv[0]);
        return -1;
    }

    int sockfd, clientfd;
    struct sockaddr_in clientaddr;
    MSG msg;
    int bytes;

    sockfd = ConnectServer(argv[1], argv[2]);

    while(1)
    {
        msg.OptCode = 0;
        fgets(msg.text, N, stdin);
        msg.text[strlen(msg.text)-1] = '\0';
        SendMsg(sockfd, &msg);

        memset(&msg, 0, sizeof(MSG));
    }

    return 0;
}