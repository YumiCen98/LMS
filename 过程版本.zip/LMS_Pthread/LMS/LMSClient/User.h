#ifndef __USER_H_
#define __USER_H_

#include <string.h>
#include "Connect.h"

int regist(int sockfd, MSG msg);

int login(int sockfd, MSG msg);

int manage(int sockfd, MSG msg);

#endif