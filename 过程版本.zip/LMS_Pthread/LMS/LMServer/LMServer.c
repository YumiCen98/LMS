#include "Connect.h"
#include "User.h"
#include <unistd.h>
#include <pthread.h>
#define OPEN_MAX 100

//给线程处理函数传递参数的结构体
typedef struct{
    int acceptfd;
    struct sockaddr_in clientaddr;
    MSG msg;
}FD_MSG;

//线程处理函数
void *thread_fun(void *arg)
{
    FD_MSG fd_msg = *(FD_MSG *)arg;
    int bytes;

    while(1)
    {
        memset(&fd_msg.msg, 0, sizeof(MSG));

        //判断客户端是否退出
        if((bytes = RecvMsg(fd_msg.acceptfd, &fd_msg.msg)) == 0)
        {
            printf(FONT_COLOR_YELLOW"[%s:%d]已退出\n"COLOR_NONE, inet_ntoa(fd_msg.clientaddr.sin_addr), ntohs(fd_msg.clientaddr.sin_port));
            close(fd_msg.acceptfd);
            break;
        }

        switch(fd_msg.msg.OptCode)
        {
            case 1:
                printf(FONT_COLOR_YELLOW"[%s:%d]注册信息\n"COLOR_NONE, inet_ntoa(fd_msg.clientaddr.sin_addr), ntohs(fd_msg.clientaddr.sin_port));
                printf("Account:%s\nPasswd:%s\n", fd_msg.msg.Account, fd_msg.msg.text);
                /*
                memset(fd_msg.msg.text, 0, N);
                strcat(fd_msg.msg.text, "regist_success");
                SendMsg(fd_msg.acceptfd, &fd_msg.msg);
                */
                do_regist(fd_msg.acceptfd, fd_msg.msg);
                break;
            case 2:
                printf(FONT_COLOR_YELLOW"[%s:%d]登录信息\n"COLOR_NONE, inet_ntoa(fd_msg.clientaddr.sin_addr), ntohs(fd_msg.clientaddr.sin_port));
                printf("Account:%s\nPasswd:%s\n", fd_msg.msg.Account, fd_msg.msg.text);
                do_login(fd_msg.acceptfd, fd_msg.msg);
                break;
            case 3:
                printf(FONT_COLOR_YELLOW"[%s:%d]管理员登录信息\n"COLOR_NONE, inet_ntoa(fd_msg.clientaddr.sin_addr), ntohs(fd_msg.clientaddr.sin_port));
                printf("Account:%s\nPasswd:%s\n", fd_msg.msg.Account, fd_msg.msg.text);
                do_manage(fd_msg.acceptfd, fd_msg.msg);
                break;
        }

        //printf("[%s:%d]:%s\n", inet_ntoa(fd_msg.clientaddr.sin_addr), ntohs(fd_msg.clientaddr.sin_port), fd_msg.msg.text);
    }
}

int main(int argc, char const *argv[])
{
    if(argc < 3)
    {
        printf("Usage：%s <ip> <port>\n", argv[0]);
        return -1;
    }

    int sockfd, clientfd;
    struct sockaddr_in clientaddr;
    MSG msg;
    int bytes;

    //创建服务器
    if((sockfd = CreateServer(argv[1], argv[2])) < 0)
    {
        printf("create server error\n");
        return -1;
    }

    //使用对线程实现TCP并发服务器
    pthread_t thread;
    FD_MSG fd_msg;

    while(1)
    {
        //等待客户端连接，并保存客户端的地址
        if((clientfd = WaitConnect(sockfd, &clientaddr)) < 0)
        {
            printf("connect server error\n");
            return -1;
        }

        //将参数传递到结构体中
        fd_msg.acceptfd = clientfd;
        fd_msg.clientaddr = clientaddr;

        //创建线程
        if(pthread_create(&thread, NULL, thread_fun, &fd_msg) != 0)
        {
            ERR_LOG("fail to pthread_create");
        }

        //设置线程为分离属性，线程退出时释放资源
        pthread_detach(thread);
    }


    return 0;
}
