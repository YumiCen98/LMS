#include "User.h"

void do_regist(int sockfd, MSG msg)
{
    memset(msg.text, 0, N);
    strcat(msg.text, "regist_success");
    SendMsg(sockfd, &msg);
    printf(FONT_COLOR_YELLOW"<regist_success>\n"COLOR_NONE);
    //memset(&msg, 0, sizeof(MSG));
}

void do_login(int sockfd, MSG msg)
{
    memset(msg.text, 0, N);
    strcat(msg.text, "login_success");
    SendMsg(sockfd, &msg);
    printf(FONT_COLOR_YELLOW"<login_success>\n"COLOR_NONE);
}

void do_manage(int sockfd, MSG msg)
{
    memset(msg.text, 0, N);
    strcat(msg.text, "manage_success");
    SendMsg(sockfd, &msg);
    printf(FONT_COLOR_YELLOW"<manage_success>\n"COLOR_NONE);
}