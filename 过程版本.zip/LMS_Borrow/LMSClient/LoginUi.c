#include "LoginUi.h"
#include "Operation.h"

void User_Centen(int sockfd, MSG msg)
{
    int Opt, ret;
    int flag = 1;


        //登录后界面
        printf(" \
            ********************\n \
            ******1、查询******\n \
            ******2、借阅******\n \
            ******3、还书******\n \
            ******0、退出******\n \
            ********************\n");

        printf(FONT_COLOR_BLUE"input:>"COLOR_NONE);
        scanf("%d", &Opt);
        switch(Opt)
        {
            case 0:
                break;
            case 1:
                book_search(sockfd, msg);
                break;
            case 2:
                book_borrow(sockfd, msg);
                break;
            case 3:
                book_return(sockfd, msg);
                break;
            default:
                printf(FONT_COLOR_RED"请输入正确的序号\n"COLOR_NONE);
                break;
        }
}