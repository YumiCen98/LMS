#include "Connect.h"
#include "User.h"
#include "Operation.h"
//#include "LoginUi.h"

int main(int argc, char const *argv[])
{
    if(argc < 3)
    {
        printf(FONT_COLOR_RED"[Usage：%s <ip> <port>]\n"COLOR_NONE, argv[0]);
        return -1;
    }

    int sockfd, clientfd;
    struct sockaddr_in clientaddr;
    MSG msg;
    int bytes;

    int Opt, ret;

    sockfd = ConnectServer(argv[1], argv[2]);

    while(1)
    {
        memset(&msg, 0, sizeof(MSG));

        //主界面
        printf(" \
            ********************\n \
            ******1、注册******\n \
            ******2、登录******\n \
            ******3、管理******\n \
            ******0、退出******\n \
            ********************\n");

        printf(FONT_COLOR_BLUE"input:>"COLOR_NONE);
        scanf("%d", &Opt);
        switch(Opt)
        {
            case 0:
                exit(0);
            case 1:
                msg.OptCode = 1;
                printf(FONT_COLOR_YELLOW"[注册界面]\n"COLOR_NONE);
                printf(FONT_COLOR_BLUE"账号:>"COLOR_NONE);
                scanf("%s", msg.Account);

                printf(FONT_COLOR_BLUE"密码:>"COLOR_NONE);
                scanf("%s", msg.text);

                regist(sockfd, msg);
                break;
            case 2:
                msg.OptCode = 2;
                printf(FONT_COLOR_YELLOW"[登录界面]\n"COLOR_NONE);
                printf(FONT_COLOR_BLUE"账号:>"COLOR_NONE);
                scanf("%s", msg.Account);

                printf(FONT_COLOR_BLUE"密码:>"COLOR_NONE);
                scanf("%s", msg.text);

                if(login(sockfd, msg) == 0)
                {
                    //User_Centen(sockfd, msg);
                    //登录后界面
                    printf(" \
                        ********************\n \
                        ******1、查询******\n \
                        ******2、借阅******\n \
                        ******3、还书******\n \
                        ******0、退出******\n \
                        ********************\n");

                    printf(FONT_COLOR_BLUE"input:>"COLOR_NONE);
                    scanf("%d", &Opt);
                    switch(Opt)
                    {
                        case 0:
                            break;
                        case 1:
                            book_search(sockfd, msg);
                            break;
                        case 2:
                            book_borrow(sockfd, msg);
                            break;
                        case 3:
                            book_return(sockfd, msg);
                            break;

                        default:
                            printf(FONT_COLOR_RED"请输入正确的序号\n"COLOR_NONE);
                            break;
                    }
                }
                else
                {
                    printf(FONT_COLOR_RED"登录失败\n"COLOR_NONE);
                }
                break;
            case 3:
                manage(sockfd, msg);
                break;

            default:
                printf(FONT_COLOR_RED"请输入正确的序号\n"COLOR_NONE);
                break;
        }
/*
        printf(FONT_COLOR_BLUE"input:>"COLOR_NONE);
        fgets(msg.text, N, stdin);
        msg.text[strlen(msg.text)-1] = '\0';

        memset(&msg, 0, sizeof(MSG));

        RecvMsg(sockfd, &msg);
        printf(FONT_COLOR_YELLOW"\n[Server Message]%s\n"COLOR_NONE, msg.text);
        */
    }

    return 0;
}