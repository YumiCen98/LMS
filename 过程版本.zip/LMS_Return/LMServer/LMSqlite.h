#ifndef __LMSQLITE_H_
#define __LMSQLITE_H_

#include <stdio.h>
#include <sqlite3.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
#include "Connect.h"

#define USERDBNAME "user.db"
#define BOOKDBNAME "book.db"

//定义颜色代码
#define COLOR_NONE          "\033[0m"       //恢复默认
#define FONT_COLOR_YELLOW   "\033[1;33m"    //黄色高亮
#define FONT_COLOR_RED      "\033[1;31m"    //红色高亮

void getdate(char data[]);

sqlite3 *do_sqlopen(const char *dbname, sqlite3 *db);

void do_createtable(sqlite3 *db, const char *sqlcmd);

int do_sqlinsert(sqlite3 *db, const char *sqlcmd);

int do_check_key(sqlite3 *db, MSG msg, const char *sqlcmd);

void sql_update(sqlite3 *db, const char *sqlcmd);

int search_callback(void *arg, int f_num, char **f_value, char **f_name);

void do_search(int sockfd, sqlite3 *db, MSG msg, const char *sqlcmd);

int borrow_callback(void *arg, int f_num, char **f_value, char **f_name);

void do_borrow(int sockfd, MSG msg, sqlite3 *book_db, sqlite3 *user_db, const char *sqlcmd);

int return_callback(void *arg, int f_num, char **f_value, char **f_name);

void do_return(int sockfd, MSG msg, sqlite3 *book_db, sqlite3 *user_db, const char *sqlcmd);

#endif